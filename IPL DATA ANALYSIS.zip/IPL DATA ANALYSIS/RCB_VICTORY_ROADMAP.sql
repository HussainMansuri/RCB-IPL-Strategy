USE ipl;



######################################################## OBJECTIVE QUESTIONS ########################################################
 -- Q1. List the different dtypes of columns in table “ball_by_ball” (using information schema)

SELECT COLUMN_NAME, DATA_TYPE FROM information_schema.columns
WHERE table_name = 'Ball_by_Ball' AND table_schema = "ipl";
  
-- Q2. What is the total number of run scored in 1st season by RCB? (bonus : also include the extra runs using the extra runs table)

WITH total_run_match_id AS (
SELECT bs.Match_id,bs.Innings_No,SUM(bs.Runs_Scored) AS 'total_runs'
FROM batsman_scored bs
GROUP BY Match_id,Innings_No),
match_teams AS (
SELECT t.Match_id,t.Innings_No,m.team_1,m.team_2,t.total_runs
FROM total_run_match_id t 
JOIN matches m 
ON t.Match_id = m.Match_id
WHERE m.Season_Id = 1),
extra_runs_cte AS (
SELECT e.Match_Id, e.Innings_No, SUM(Extra_Runs) AS total_extras
FROM extra_runs e
JOIN Matches m
ON e.Match_Id = m.Match_Id
GROUP BY e.Match_Id,e.Innings_No),
runs_per_match AS (
SELECT t.Match_id,t.Innings_No,m.team_1,m.team_2,m.Toss_Winner,m.Toss_Decide,
SUM(CASE WHEN m.Toss_Decide = 1 AND m.Toss_Winner = 2 AND t.Innings_No = 2 AND e.Innings_No =2 THEN t.total_runs + e.total_extras
	  WHEN m.Toss_Decide = 2 AND m.Toss_Winner = 2 AND t.Innings_No = 1 AND e.Innings_No =1 THEN t.total_runs + e.total_extras  
      WHEN m.Toss_Decide = 1 AND m.Toss_Winner != 2 AND t.Innings_No = 1 AND e.Innings_No =1 THEN t.total_runs + e.total_extras
      WHEN m.Toss_Decide = 2 AND m.Toss_Winner !=2 AND t.Innings_No = 2 AND e.Innings_No =2 THEN t.total_runs  + e.total_extras
      ELSE 0 END) AS total_runs
FROM total_run_match_id t 
JOIN matches m 
ON t.Match_id = m.Match_id
JOIN extra_runs_cte e
ON t.Match_Id = e.Match_Id AND t.Innings_No = e.Innings_No 
WHERE m.Season_Id = 1 AND (team_1 = 2 OR team_2 = 2)
GROUP BY m.Match_Id
ORDER BY m.Match_Id, t.Innings_No)
SELECT SUM(total_runs) AS total_runs_scored
FROM runs_per_match;



-- Q3. How many players were more than age of 25 during season 2 ?

WITH player_age AS (
SELECT Player_Id, TIMESTAMPDIFF(YEAR,DOB,(SELECT MIN(match_date) FROM matches
WHERE Season_Id = 2)) - (DATE_FORMAT(DOB, '%m%d') > DATE_FORMAT((SELECT MIN(Match_Date) FROM matches WHERE Season_Id = 2), '%m%d')) 
       AS age
FROM player)
SELECT COUNT(player_id) AS no_of_player_above_25
FROM player_age
WHERE age > 25;



-- Q4. How many matches did RCB win in season 1 ?
SELECT COUNT(DISTINCT Match_Id) AS no_of_matches_won_in_S1
FROM matches
WHERE Match_Winner = 2 AND Season_Id = 1;




-- Q5. List top 10 players according to their strike rate in last 4 seasons

WITH runs_scored AS (
SELECT b.striker, SUM(bs.Runs_scored) AS total_runs_scored
FROM batsman_scored bs 
JOIN ball_by_ball b
ON b.Match_Id = bs.Match_Id AND
b.Over_Id = bs.Over_Id AND
b.Ball_id = bs.Ball_id AND
b.Innings_No = bs.Innings_No
JOIN matches m 
ON m.Match_Id = bs.Match_Id
WHERE m.Season_Id >=6
GROUP BY b.striker
ORDER BY total_runs_scored DESC),
balls_faced AS (
SELECT b.striker,COUNT(b.ball_id) AS no_of_balls_played
FROM ball_by_ball b
JOIN matches m
ON m.Match_Id = b.Match_Id
WHERE m.Season_Id >= 6
GROUP BY Striker)

SELECT b.striker AS player_id, p.Player_Name,r.total_runs_scored,b.no_of_balls_played, ROUND((r.total_runs_scored/b.no_of_balls_played),2)*100 AS strike_rate
FROM runs_scored r
JOIN balls_faced b 
ON r.striker = b.striker
JOIN player p 
ON b.striker = p.Player_Id
HAVING b.no_of_balls_played > 100
ORDER BY strike_rate DESC
LIMIT 10;





-- Q6. What is the average runs scored by each batsman considering all the seasons?

WITH per_player_per_season_runs AS
(SELECT b.striker,m.Season_Id, SUM(bs.Runs_scored) AS total_runs_scored
FROM batsman_scored bs 
JOIN ball_by_ball b
ON b.Match_Id = bs.Match_Id AND
b.Over_Id = bs.Over_Id AND
b.Ball_id = bs.Ball_id AND
b.Innings_No = bs.Innings_No
JOIN matches m 
ON m.Match_Id = bs.Match_Id
GROUP BY b.striker,m.Season_Id
ORDER BY b.striker ASC,m.season_Id ASC),
avg_window AS (
SELECT *, AVG(total_runs_scored) OVER(PARTITION BY striker) AS avg_runs
FROM per_player_per_season_runs)
SELECT DISTINCT p.player_Name,ROUND(a.avg_runs,2) AS Average_Runs
FROM avg_window a
JOIN Player p
ON p.Player_Id = a.striker
WHERE a.avg_runs >= 1
ORDER BY avg_runs DESC;



-- Q7. What are the average wickets taken by each bowler considering all the seasons

WITH wickets_count_per_player_per_season AS
(SELECT  b.Bowler, m.Season_Id,  COUNT(w.Player_Out) AS wickets_taken
FROM ball_by_ball b
JOIN wicket_taken w 
ON b.Match_Id = w.Match_Id AND
b.Over_Id = w.Over_Id AND
b.Ball_Id = w.Ball_Id AND
b.Innings_No = w.Innings_No
JOIN Matches m 
ON m.Match_Id = w.Match_Id
GROUP BY 1,2
ORDER BY b.Bowler ASC, m.Season_Id ASC),
avg_per_season AS (
SELECT *, AVG(wickets_taken) OVER(PARTITION BY Bowler) AS avg_wicket_per_bowler
FROM wickets_count_per_player_per_season)

SELECT DISTINCT p.Player_Name,ROUND(a.avg_wicket_per_bowler,2) AS Avg_wicket
FROM avg_per_season a
JOIN Player p
ON p.Player_Id = a.Bowler
WHERE a.avg_wicket_per_bowler > 0
ORDER BY Avg_wicket DESC;



-- Q8. List all the players who have average runs scored greater than overall average and who have taken wickets greater than overall average.

#	A. Players with average runs more than overall_average

WITH per_player_runs AS                                        ####Overall total runs
(SELECT b.striker,SUM(bs.Runs_scored) AS total_runs_scored
FROM batsman_scored bs 
JOIN ball_by_ball b
ON b.Match_Id = bs.Match_Id AND
b.Over_Id = bs.Over_Id AND
b.Ball_id = bs.Ball_id AND
b.Innings_No = bs.Innings_No
JOIN matches m 
ON m.Match_Id = bs.Match_Id
GROUP BY b.striker
ORDER BY b.striker ASC,m.season_Id ASC),

avg_overall_runs AS
(SELECT ROUND(AVG(total_runs_scored),2) AS overall_avg_runs 
FROM per_player_runs),

per_season_career_runs AS (									#Average runs through each season
SELECT b.striker,SUM(bs.Runs_scored) AS total_runs_scored
FROM batsman_scored bs 
JOIN ball_by_ball b
ON b.Match_Id = bs.Match_Id AND
b.Over_Id = bs.Over_Id AND
b.Ball_id = bs.Ball_id AND
b.Innings_No = bs.Innings_No
JOIN matches m 
ON m.Match_Id = bs.Match_Id
GROUP BY b.striker,m.Season_Id
ORDER BY b.striker ASC,m.season_Id ASC),

avg_career_runs AS                                         #Average runs scored overall
(SELECT striker,AVG(total_runs_scored) OVER(PARTITION BY striker) AS avg_runs_career
FROM per_season_career_runs
GROUP BY 1)

SELECT p.Player_Name,cr.avg_runs_career
FROM avg_career_runs cr
JOIN player p
ON p.Player_Id = cr.Striker
WHERE cr.avg_runs_career > (SELECT ROUND(AVG(total_runs_scored),2) AS overall_avg_runs 
FROM per_player_runs)
ORDER BY avg_runs_career DESC;


# B. Players with more wickets then overall average wickets

WITH wickets_count_per_player AS                                #Total wickets overall
(SELECT  b.Bowler, COUNT(w.Player_Out) AS wickets_taken
FROM ball_by_ball b
JOIN wicket_taken w 
ON b.Match_Id = w.Match_Id AND
b.Over_Id = w.Over_Id AND
b.Ball_Id = w.Ball_Id AND
b.Innings_No = w.Innings_No
JOIN Matches m 
ON m.Match_Id = w.Match_Id
GROUP BY 1
ORDER BY b.Bowler ASC, m.Season_Id ASC),

avg_wickets_overall AS                                       #Average wicket 
(SELECT DISTINCT ROUND(AVG(wickets_taken),2) AS avg_wicket_count
FROM wickets_count_per_player
ORDER BY Bowler ASC),

avg_season_wickets AS (                               #Average wickets per season
SELECT  b.Bowler,m.Season_Id, COUNT(w.Player_Out) AS wickets_taken
FROM ball_by_ball b
JOIN wicket_taken w 
ON b.Match_Id = w.Match_Id AND
b.Over_Id = w.Over_Id AND
b.Ball_Id = w.Ball_Id AND
b.Innings_No = w.Innings_No
JOIN Matches m 
ON m.Match_Id = w.Match_Id
GROUP BY 1,2
ORDER BY b.Bowler ASC, m.Season_Id ASC),

avg_career_wicket AS                                       #Average career wickets for each player
(SELECT bowler,AVG(wickets_taken) OVER(PARTITION BY bowler) AS avg_wickets_career
FROM avg_season_wickets
GROUP BY bowler)
											
SELECT p.Player_Name,cw.avg_wickets_career						 #Players with more average wickets then overall average
FROM avg_career_wicket cw 
JOIN player p
ON p.Player_Id = cw.bowler
WHERE avg_wickets_career > (SELECT DISTINCT ROUND(AVG(wickets_taken),2) AS avg_wicket_count
FROM wickets_count_per_player
ORDER BY Bowler ASC)
ORDER BY avg_wickets_career DESC;





-- Q9. Create a table rcb_record table that shows wins and losses of RCB in an individual venue.

DROP TABLE IF EXISTS rcb_record_table;

CREATE TABLE IF NOT EXISTS rcb_record_table AS 
WITH rcb_record AS 
(SELECT m.Venue_Id, v.Venue_Name,
SUM(CASE WHEN Match_Winner = 2 THEN 1 ELSE 0 END) AS Win_record,
SUM(CASE WHEN Match_Winner != 2 THEN 1 ELSE 0 END) AS Loss_record
FROM matches m
JOIN venue v 
ON m.Venue_Id = v.Venue_Id
WHERE (Team_1 = 2 OR Team_2 = 2) AND m.Outcome_type != 2
GROUP BY 1,2)

SELECT *, Win_record + Loss_record AS Total_Played,
ROUND((Win_record/(Win_record + Loss_record))*100,2) AS Win_percentage, ROUND((Loss_record/(Win_record + Loss_record))*100,2) AS Loss_percentage
FROM rcb_record
ORDER BY Venue_Id;

SELECT Venue_Name,Win_record,Loss_record,Total_Played,Win_percentage,Loss_percentage FROM rcb_record_table;


-- Q10. What is the impact of bowling style on wickets taken

WITH no_of_wicket_per_bowler AS (
SELECT bb.bowler,  COUNT(w.Player_Out) AS no_of_wickets
FROM wicket_taken w 
JOIN ball_by_ball bb 
ON w.Match_Id = bb.Match_Id 
    AND w.Over_Id = bb.Over_Id 
    AND w.Ball_Id = bb.Ball_Id 
    AND w.Innings_No = bb.Innings_No
GROUP BY bb.Bowler),
bowler_skill_wicket AS
(SELECT  n.bowler, st.Bowling_skill, no_of_wickets 
FROM no_of_wicket_per_bowler n 
JOIN player p
ON n.bowler = p.Player_Id
JOIN bowling_style st
ON st.Bowling_Id = p.Bowling_skill
ORDER BY no_of_wickets DESC)
SELECT Bowling_skill AS Bowling_Style, SUM(no_of_wickets) AS total_wickets_taken
FROM bowler_skill_wicket
GROUP BY Bowling_skill
ORDER BY total_wickets_taken DESC;



-- Q11.	Write the sql query to provide a status of 
-- whether the performance of the team better than the previous year performance 
-- on the basis of number of runs scored by the team in the season and number of wickets taken.

WITH total_run_match_id AS (					#Total runs per innings per match
SELECT Match_id,Innings_No,SUM(Runs_Scored) AS 'total_runs'
FROM batsman_scored
GROUP BY Match_id,Innings_No),

total_runs_per_season AS (                            
SELECT m.Season_Id,
SUM(CASE WHEN m.Toss_Decide = 1 AND m.Toss_Winner = 2 AND Innings_No = 2 THEN t.total_runs 
	  WHEN m.Toss_Decide = 2 AND m.Toss_Winner = 2 AND Innings_No = 1 THEN t.total_runs  
      WHEN m.Toss_Decide = 1 AND m.Toss_Winner != 2 AND Innings_No = 1 THEN t.total_runs 
      WHEN m.Toss_Decide = 2 AND m.Toss_Winner !=2 AND Innings_No = 2 THEN t.total_runs   
      ELSE 0 END) AS total_runs
FROM total_run_match_id t 
JOIN matches m 
ON t.Match_id = m.Match_id
WHERE team_1 = 2 OR team_2 = 2
GROUP BY m.Season_Id
ORDER BY m.Match_Id, t.Innings_No),

total_wickets_per_match_innings AS (
SELECT w.Match_id, w.Innings_No,COUNT(w.Player_out) AS total_wickets
FROM wicket_taken w 
JOIN matches m
ON m.Match_Id = w.Match_Id
WHERE Team_1 = 2 OR Team_2 = 2
GROUP BY 1,2),

total_wickets_per_season AS (
SELECT m.Season_Id, 
SUM(CASE WHEN m.Toss_Decide = 1 AND m.Toss_Winner = 2 AND Innings_No = 1 THEN w.total_wickets
	  WHEN m.Toss_Decide = 2 AND m.Toss_Winner = 2 AND Innings_No = 2 THEN w.total_wickets 
      WHEN m.Toss_Decide = 1 AND m.Toss_Winner != 2 AND Innings_No = 2 THEN w.total_wickets
      WHEN m.Toss_Decide = 2 AND m.Toss_Winner !=2 AND Innings_No = 1 THEN w.total_wickets  
      ELSE 0 END) AS total_wickets
FROM total_wickets_per_match_innings w 
JOIN matches m 
ON m.Match_Id = w.Match_Id
GROUP BY m.Season_Id)

SELECT r.Season_Id, r.total_runs, w.total_wickets
FROM total_wickets_per_season w
JOIN total_runs_per_season r 
ON r.Season_Id = w.Season_Id
ORDER BY r.Season_Id;



-- Q12.	Can you derive more KPIs for the team strategy if possible?


 -- KPI #1 Boundary %
 
SELECT pm.Player_Id, p.Player_Name,
       ROUND((SUM(CASE WHEN b.Runs_Scored = 4 THEN 1 ELSE 0 END) / COUNT(*)),2) * 100 AS Four_Percentage,
       ROUND((SUM(CASE WHEN b.Runs_Scored = 6 THEN 1 ELSE 0 END) / COUNT(*)),2) * 100 AS Six_Percentage
FROM batsman_scored b
JOIN matches m 
ON m.Match_Id = b.Match_Id
JOIN player_match pm
ON m.Match_Id = pm.Match_Id
JOIN player p
ON pm.Player_Id = p.Player_Id
WHERE Season_Id IN (SELECT DISTINCT Season_Id FROM matches WHERE Team_1 = 2 OR Team_2 = 2)
GROUP BY 1,2
ORDER BY Six_Percentage DESC,Four_Percentage DESC
LIMIT 15;



-- KPI #2 Bowling strike rate (Lower is better)

SELECT bb.Bowler, p.Player_Name,
       ROUND(COUNT(bb.Ball_Id) / COUNT(w.Player_Out),2) AS Strike_Rate
FROM ball_by_ball bb
LEFT JOIN wicket_taken w 
       ON bb.Match_Id = w.Match_Id 
       AND bb.Over_Id = w.Over_Id 
       AND bb.Ball_Id = w.Ball_Id
JOIN player p
ON p.Player_Id = bb.Bowler
WHERE bb.Team_Bowling = 2
GROUP BY bb.Bowler
HAVING Strike_Rate IS NOT NULL
ORDER BY Strike_Rate ASC
LIMIT 15;



-- Q13.	Using SQL, write a query to find out average wickets taken by each bowler in each venue. Also rank the gender according to the average value.
WITH player_wickets AS (
    SELECT v.Venue_Id,v.Venue_Name, 
           p.Player_Name, 
           COUNT(w.Player_Out) AS total_wickets, 
           COUNT(DISTINCT m.Match_Id) AS matches_played  -- Distinct matches where the player bowled
    FROM wicket_taken w
    JOIN ball_by_ball b ON w.Match_Id = b.Match_Id AND w.Over_Id = b.Over_Id AND w.Ball_Id = b.Ball_Id
    JOIN matches m ON b.Match_Id = m.Match_Id
    JOIN player p ON p.Player_Id = b.Bowler
    JOIN venue v ON v.Venue_Id = m.Venue_Id
    GROUP BY v.Venue_Name, p.Player_Name
),
unranked_table AS
(SELECT Venue_Id,Venue_Name, Player_Name, 
       total_wickets, 
       matches_played,
       ROUND(total_wickets / matches_played, 2) AS avg_wickets
FROM player_wickets)
SELECT *, DENSE_RANK() OVER(ORDER BY avg_wickets DESC) AS Ranking
FROM unranked_table
WHERE matches_played >10;



-- Q14.	Which of the given players have consistently performed well in past seasons? 

#Bowling performance

SELECT   p.Player_Id,p.Player_Name,m.Season_Id,  COUNT(w.Player_Out) AS wickets_taken
FROM ball_by_ball b
JOIN wicket_taken w 
ON b.Match_Id = w.Match_Id AND
b.Over_Id = w.Over_Id AND
b.Ball_Id = w.Ball_Id AND
b.Innings_No = w.Innings_No
JOIN Matches m 
ON m.Match_Id = w.Match_Id
JOIN Player p
ON p.Player_Id = b.Bowler
GROUP BY b.bowler,p.Player_Name,m.Season_Id
HAVING COUNT(m.Season_Id) > 2
ORDER BY b.Bowler ASC, m.Season_Id ASC;

#Batting performance

SELECT p.player_Name,m.Season_Id, SUM(bs.Runs_scored) AS total_runs_scored
FROM batsman_scored bs 
JOIN ball_by_ball b
ON b.Match_Id = bs.Match_Id AND
b.Over_Id = bs.Over_Id AND
b.Ball_id = bs.Ball_id AND
b.Innings_No = bs.Innings_No
JOIN matches m 
ON m.Match_Id = bs.Match_Id
JOIN Player p 
ON p.Player_Id = b.Striker
GROUP BY p.Player_Name,m.Season_Id
HAVING COUNT(m.Season_Id) > 2
ORDER BY b.Striker ASC,m.season_Id ASC;



-- Q15.	Are there players whose performance is more suited to specific venues or conditions? 

#Batting performance

SELECT p.Player_Name, v.Venue_Name, 
       SUM(bs.Runs_Scored) AS Total_Runs, 
       COUNT(bs.Ball_Id) AS Balls_Faced,
       ROUND(SUM(bs.Runs_Scored) / COUNT(bs.Ball_Id), 2)*100 AS Strike_Rate
FROM ball_by_ball b
JOIN batsman_scored bs ON b.Match_Id = bs.Match_Id 
AND b.Over_Id = bs.Over_Id AND b.Ball_Id = bs.Ball_Id AND b.Innings_No = bs.Innings_No
JOIN matches m ON m.Match_Id = b.Match_Id
JOIN player p ON p.Player_Id = b.Striker
JOIN venue v ON m.Venue_Id = v.Venue_Id
GROUP BY p.Player_Name, v.Venue_Name
HAVING Total_Runs > 0 AND Balls_Faced > 100
ORDER BY Total_Runs DESC,p.Player_Name;


#Bowling performance
SELECT p.Player_Name, v.Venue_Name, 
       COUNT(w.Player_Out) AS Wickets_Taken, 
       COUNT(b.Ball_Id) AS Balls_Bowled
FROM ball_by_ball b
JOIN wicket_taken w ON b.Match_Id = w.Match_Id 
AND b.Over_Id = w.Over_Id AND b.Ball_Id = w.Ball_Id AND b.Innings_No = w.Innings_No
JOIN matches m ON m.Match_Id = w.Match_Id
JOIN player p ON p.Player_Id = b.Bowler
JOIN venue v ON m.Venue_Id = v.Venue_Id
GROUP BY p.Player_Name, v.Venue_Name
HAVING Balls_Bowled > 5
ORDER BY  Wickets_Taken DESC,p.Player_Name;




######################################################## SUBJECTIVE QUESTIONS ########################################################

-- Q1.	How does toss decision have affected the result of the match ?
-- (which visualisations could be used to better present your answer) 
-- And is the impact limited to only specific venues?

SELECT v.Venue_Id,v.Venue_Name, 
       CASE WHEN m.Toss_Decide = 1 THEN "Field" ELSE "Bat" END AS Toss_Decide, 
       SUM(CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END) AS Toss_Winner_Wins, 
       SUM(CASE WHEN m.Toss_Winner != m.Match_Winner THEN 1 ELSE 0 END) AS Toss_Winner_Losses,
       COUNT(m.Match_Id) AS Total_Matches,
       ROUND((SUM(CASE WHEN m.Toss_Winner = m.Match_Winner THEN 1 ELSE 0 END) / COUNT(m.Match_Id)) * 100, 2) AS Win_Percentage
FROM matches m
JOIN venue v ON m.Venue_Id = v.Venue_Id
GROUP BY v.Venue_Name, m.Toss_Decide
ORDER BY v.Venue_Name, m.Toss_Decide;



-- Q2. Suggest some of the players who would be best fit for the team?

#List of consistently performing batsmen 

SELECT p.Player_Name, 
       SUM(bs.Runs_Scored) AS Total_Runs, 
       COUNT(bb.Ball_Id) AS Balls_Faced, 
       ROUND((SUM(bs.Runs_Scored) / COUNT(bb.Ball_Id))*100,2) AS Strike_Rate, 
       ROUND(SUM(bs.Runs_Scored) / COUNT(DISTINCT m.Match_Id), 2) AS Average_Runs
FROM player p
JOIN ball_by_ball bb ON p.Player_Id = bb.Striker
JOIN batsman_scored bs ON bb.Match_Id = bs.Match_Id AND bb.Innings_No = bs.Innings_No AND bb.Over_Id = bs.Over_Id AND bb.Ball_Id = bs.Ball_Id
JOIN matches m ON bb.Match_Id = m.Match_Id
WHERE m.Season_Id >= 4
GROUP BY p.Player_Name
ORDER BY Total_Runs DESC,Strike_Rate DESC
LIMIT 10;

#List of consistent bowlers

SELECT p.Player_Name, 
       COUNT(w.Player_Out) AS Wickets_Taken, 
       ROUND(SUM(bb.Ball_Id) / COUNT(w.Player_Out),2) AS Strike_Rate, 
       ROUND(SUM(bs.Runs_Scored) / (SUM(bb.Ball_Id)/6),2) AS Economy_Rate
FROM ball_by_ball bb
JOIN batsman_scored bs 
ON bb.Match_Id = bs.Match_Id AND bb.ball_Id = bs.ball_Id AND bb.Over_Id = bs.Over_Id
JOIN Player p 
ON bb.bowler = p.Player_Id
JOIN matches m ON bb.Match_Id = m.Match_Id
JOIN wicket_taken w 
ON bb.Match_Id = w.Match_Id AND bb.Over_Id = w.Over_Id AND bb.Innings_No = w.Innings_No AND bb.Ball_Id = w.Ball_Id
WHERE m.Season_Id >=4
GROUP BY p.Player_Name
ORDER BY Wickets_Taken DESC, Economy_Rate ASC, Strike_Rate ASC
LIMIT 10;



-- Q3. What are some of parameters that should be focused while selecting the players?

#Key parameters for selecting players

# A. Death over bowling performance
SELECT p.Player_Name, 
       SUM(CASE WHEN bb.Over_Id >= 16 AND bb.Over_Id <= 20  AND p.Player_Id IN (SELECT Bowler FROM ball_by_ball) THEN b.Runs_Scored ELSE 0 END) AS Death_Over_Runs_Conceded
FROM player p
JOIN ball_by_ball bb ON p.Player_Id = bb.Striker OR p.Player_Id = bb.Bowler
JOIN batsman_scored b ON bb.Match_Id = b.Match_Id AND bb.Over_Id = b.Over_Id AND bb.Ball_Id = b.Ball_Id AND bb.Innings_No = b.Innings_No
GROUP BY p.Player_Name
HAVING COUNT(bb.Ball_Id) > 100 AND Death_Over_Runs_Conceded != 0
ORDER BY Death_Over_Runs_Conceded ASC
LIMIT 10;


# B. Batting performance accross different venues

SELECT p.Player_Name, 
       v.Venue_Id,v.Venue_Name, 
       SUM(b.Runs_Scored) AS Total_Runs, 
       COUNT(b.Ball_Id) AS Balls_Faced, 
       ROUND(SUM(b.Runs_Scored) / COUNT(b.Ball_Id), 2)*100 AS Strike_Rate
FROM player p
JOIN ball_by_ball bb ON p.Player_Id = bb.Striker
JOIN matches m ON bb.Match_Id = m.Match_Id
JOIN venue v ON m.Venue_Id = v.Venue_Id
JOIN batsman_scored b 
ON b.Match_Id = bb.Match_Id AND b.Over_Id = bb.Over_Id AND b.Ball_Id = bb.Ball_Id AND b.Innings_No = bb.Innings_No
GROUP BY p.Player_Name, v.Venue_Name
ORDER BY Total_Runs DESC, Strike_Rate DESC
LIMIT 10;



-- Q4. Which players offer versatility in their skills and can contribute effectively with both bat and ball? (can you visualize the data for the same)

#We can find all-rounder performance for all players
WITH batting_performance AS (
    SELECT p.Player_Id, p.Player_Name,
           SUM(b.Runs_Scored) AS Total_Runs,
           COUNT(bb.Ball_Id) AS Balls_Faced,
           ROUND((SUM(b.Runs_Scored) / COUNT(bb.Ball_Id))*100,2) AS Batting_Strike_Rate
    FROM player p
    JOIN ball_by_ball bb ON p.Player_Id = bb.Striker
    JOIN batsman_scored b ON bb.Match_Id = b.Match_Id 
                          AND bb.Over_Id = b.Over_Id 
                          AND bb.Ball_Id = b.Ball_Id 
                          AND bb.Innings_No = b.Innings_No
    GROUP BY p.Player_Id, p.Player_Name
),
bowling_performance AS (
    SELECT p.Player_Id, p.Player_Name, 
           COUNT(w.Player_Out) AS Total_Wickets,
           ROUND(SUM(bb.Team_Batting) / COUNT(bb.Ball_Id),2) AS Economy_Rate
    FROM player p
    JOIN ball_by_ball bb ON p.Player_Id = bb.Bowler
    JOIN wicket_taken w ON bb.Match_Id = w.Match_Id 
                        AND bb.Over_Id = w.Over_Id 
                        AND bb.Ball_Id = w.Ball_Id 
                        AND bb.Innings_No = w.Innings_No
    GROUP BY p.Player_Id, p.Player_Name
)
SELECT bp.Player_Id, bp.Player_Name, 
       bp.Total_Runs, bp.Batting_Strike_Rate, bp.Balls_Faced,
       bw.Total_Wickets, bw.Economy_Rate
FROM batting_performance bp
JOIN bowling_performance bw ON bp.Player_Id = bw.Player_Id
ORDER BY bp.Batting_Strike_Rate  DESC, bw.Economy_Rate ASC
LIMIT 10;



-- Q5.	Are there players whose presence positively influences the morale and performance of the team? (justify your answer using visualisation)

WITH player_influence AS (
    -- Check team's win rate when player is in the playing 11
    SELECT pm.Player_Id, p.Player_Name,
           SUM(CASE WHEN m.Match_Winner = pm.Team_Id THEN 1 ELSE 0 END) AS Wins_With_Player,
           COUNT(pm.Match_Id) AS Matches_With_Player
    FROM player_match pm
    JOIN matches m ON pm.Match_Id = m.Match_Id
    JOIN player p ON pm.Player_Id = p.Player_Id
    WHERE pm.Team_Id = 2  
    GROUP BY pm.Player_Id, p.Player_Name
),
team_win_rate AS (
    -- Calculate overall team win rate
    SELECT m.Team_1 AS Team_Id,
           SUM(CASE WHEN m.Match_Winner = 2 THEN 1 ELSE 0 END) AS Wins_Without_Player,
           COUNT(m.Match_Id) AS Total_Matches
    FROM matches m
    WHERE (m.Team_1 = 2 OR m.Team_2 = 2)  -- RCB
    GROUP BY m.Team_1
)
SELECT pi.Player_Name, pi.Wins_With_Player, pi.Matches_With_Player,
       ROUND((pi.Wins_With_Player / pi.Matches_With_Player) * 100, 2) AS Win_Rate_With_Player,
       tw.Wins_Without_Player, tw.Total_Matches,
       ROUND((tw.Wins_Without_Player / tw.Total_Matches) * 100, 2) AS Win_Rate_Without_Player
FROM player_influence pi
JOIN team_win_rate tw ON pi.Player_Id = tw.Team_Id
ORDER BY Win_Rate_With_Player DESC;



-- Q6. What would you suggest to RCB before going to mega auction?  

# Identify good all-rounders for better team combinations.

WITH batting_performance AS (
    SELECT p.Player_Id, p.Player_Name,
           SUM(b.Runs_Scored) AS Total_Runs,
           COUNT(bb.Ball_Id) AS Balls_Faced,
           ROUND((SUM(b.Runs_Scored) / COUNT(bb.Ball_Id)),2) * 100 AS Batting_Strike_Rate
    FROM player p
    JOIN ball_by_ball bb ON p.Player_Id = bb.Striker
    JOIN batsman_scored b ON bb.Match_Id = b.Match_Id 
                          AND bb.Over_Id = b.Over_Id 
                          AND bb.Ball_Id = b.Ball_Id 
                          AND bb.Innings_No = b.Innings_No
    GROUP BY p.Player_Id, p.Player_Name
),
bowling_performance AS (
    SELECT p.Player_Id, p.Player_Name, 
           COUNT(w.Player_Out) AS Total_Wickets,
           ROUND(SUM(bs.Runs_Scored) / (COUNT(bb.Ball_Id) / 6.0), 2) AS Economy_Rate -- Correct Economy Rate Calculation
    FROM player p
    JOIN ball_by_ball bb ON p.Player_Id = bb.Bowler
    LEFT JOIN wicket_taken w ON bb.Match_Id = w.Match_Id 
                        AND bb.Over_Id = w.Over_Id 
                        AND bb.Ball_Id = w.Ball_Id 
                        AND bb.Innings_No = w.Innings_No
    JOIN batsman_scored bs ON bs.Match_Id = bb.Match_Id
                           AND bb.Over_Id = bs.Over_Id 
                           AND bb.Ball_Id = bs.Ball_Id 
                           AND bb.Innings_No = bs.Innings_No
    GROUP BY p.Player_Id, p.Player_Name
    HAVING COUNT(bb.Ball_Id) > 100
)
SELECT DISTINCT bp.Player_Id, bp.Player_Name, 
       bp.Total_Runs, bp.Batting_Strike_Rate, bp.Balls_Faced,
       bw.Total_Wickets, bw.Economy_Rate
FROM batting_performance bp
JOIN bowling_performance bw ON bp.Player_Id = bw.Player_Id
JOIN player_match pm ON bp.Player_Id = pm.Player_Id
WHERE pm.Role_Id NOT IN (SELECT Role_Id FROM rolee WHERE Role_Desc IN ("Keeper","CaptainKeeper"))
AND bp.Balls_Faced > 100
ORDER BY bp.Batting_Strike_Rate DESC, bw.Economy_Rate ASC
LIMIT 10;


-- Q7. What do you think could be the factors contributing to the high-scoring matches and the impact on viewership and team strategies?

/* Powerplay and Death Over Utilization: In high-scoring matches, teams aim to maximize the powerplay (overs 1-6) and death overs (Overs 16-20) by scoring aggressively. */

SELECT t.Team_Name,
       SUM(CASE WHEN bb.Over_Id BETWEEN 1 AND 6 THEN b.Runs_Scored ELSE 0 END) AS Powerplay_Runs,
       SUM(CASE WHEN bb.Over_Id BETWEEN 16 AND 20 THEN b.Runs_Scored ELSE 0 END) AS Death_Over_Runs
FROM team t
JOIN matches m ON t.Team_Id = m.Team_1 OR t.Team_Id = m.Team_2
JOIN ball_by_ball bb ON m.Match_Id = bb.Match_Id
JOIN batsman_scored b ON bb.Match_Id = b.Match_Id AND bb.Over_Id = b.Over_Id AND bb.Ball_Id = b.Ball_Id
GROUP BY t.Team_Name
ORDER BY Powerplay_Runs DESC, Death_Over_Runs DESC;


/* High Scoring Venues: Some venues favour the batsmen more then others, venues play a significant role in a high-scoring match */

SELECT v.Venue_Name, 
       AVG(match_runs.Total_Runs) AS Avg_Runs_Per_Match,
       COUNT(m.Match_Id) AS Total_Matches
FROM venue v
JOIN matches m ON v.Venue_Id = m.Venue_Id
JOIN (
    SELECT bb.Match_Id, SUM(b.Runs_Scored) AS Total_Runs
    FROM ball_by_ball bb
    JOIN batsman_scored b ON bb.Match_Id = b.Match_Id 
        AND bb.Over_Id = b.Over_Id 
        AND bb.Ball_Id = b.Ball_Id
    GROUP BY bb.Match_Id
) AS match_runs ON m.Match_Id = match_runs.Match_Id
GROUP BY v.Venue_Name
ORDER BY Total_Matches DESC,Avg_Runs_Per_Match DESC
LIMIT 10;



-- Q8.	Analyze the impact of home ground advantage on team performance and identify strategies to maximize this advantage for RCB.

# Home vs Away Win/Loss record
WITH win_loss_record AS (
		SELECT m.Match_Id, v.Venue_Name,
        CASE WHEN m.Match_Winner = 2 THEN 'Win' ELSE 'Loss'
        END AS Result,
        CASE WHEN v.Venue_Id = 1 THEN 'Home' ELSE 'Away'
		END AS Venue_Type
		FROM matches m
		JOIN venue v ON m.Venue_Id = v.Venue_Id
		WHERE (m.Team_1 = 2 OR m.Team_2 = 2) AND Outcome_type !=  2
		)
		SELECT 
		Venue_Type,
		COUNT(CASE WHEN Result = 'Win' THEN 1 END) AS Wins,
		COUNT(CASE WHEN Result = 'Loss' THEN 1 END) AS Losses,
		COUNT(*) AS Total_Matches,
		ROUND(COUNT(CASE WHEN Result = 'Win' THEN 1 END) / COUNT(*) * 100, 2) AS Win_Percentage
		FROM win_loss_record
		GROUP BY Venue_Type;


#Home away batting performance

WITH rcb_run_stats AS (
    SELECT m.Match_Id, v.Venue_Name,
        CASE WHEN v.Venue_Id = 1 THEN 'Home' ELSE 'Away'
        END AS Venue_Type,
        SUM(CASE WHEN bb.Team_Batting = 2 THEN b.Runs_Scored ELSE 0 END) AS Runs_Scored,
        SUM(CASE WHEN bb.Team_Bowling = 2 THEN b.Runs_Scored ELSE 0 END) AS Runs_Conceded
    FROM matches m
    JOIN venue v ON m.Venue_Id = v.Venue_Id
    JOIN ball_by_ball bb ON m.Match_Id = bb.Match_Id
    JOIN batsman_scored b ON bb.Match_Id = b.Match_Id 
    AND bb.Over_Id = b.Over_Id 
    AND bb.Ball_Id = b.Ball_Id
    WHERE (m.Team_1 = 2 OR m.Team_2 = 2) -- 2 is the team ID for RCB
    GROUP BY m.Match_Id, v.Venue_Name
)
SELECT Venue_Type,
    ROUND(AVG(Runs_Scored),2) AS Avg_Runs_Scored,
    ROUND(SUM(Runs_Scored),2) AS Total_runs_scored
FROM rcb_run_stats
GROUP BY Venue_Type;


#Bowling performance at home

WITH bowling_performance AS (
    SELECT v.Venue_Name,
        CASE WHEN v.Venue_Id = 1 THEN 'Home' ELSE 'Away'
        END AS Venue_Type,
        SUM(CASE WHEN bb.Team_Bowling = 2 THEN b.Runs_Scored ELSE 0 END) AS Runs_Conceded,
        COUNT(CASE WHEN bb.Team_Bowling = 2 THEN w.Player_Out ELSE NULL END) AS Wickets_Taken,
        COUNT(CASE WHEN bb.Team_Bowling = 2 THEN bb.Ball_Id ELSE NULL END) AS Balls_Bowled
    FROM matches m
    JOIN venue v ON m.Venue_Id = v.Venue_Id
    JOIN ball_by_ball bb ON m.Match_Id = bb.Match_Id
    JOIN wicket_taken w ON bb.Match_Id = w.Match_Id 
        AND bb.Over_Id = w.Over_Id 
        AND bb.Ball_Id = w.Ball_Id
    JOIN batsman_scored b ON bb.Match_Id = b.Match_Id
        AND bb.Over_Id = b.Over_Id 
        AND bb.Ball_Id = b.Ball_Id
    WHERE (m.Team_1 = 2 OR m.Team_2 = 2) -- 2 is the team ID for RCB
    GROUP BY v.Venue_Name
)
SELECT Venue_Type,
    ROUND(SUM(Wickets_taken),2) AS Total_Wickets_taken,
    ROUND(SUM(Runs_Conceded) / SUM(Balls_Bowled), 2) AS Economy_Rate
FROM bowling_performance
GROUP BY Venue_Type;



-- Q9.	Come up with a visual and analytical analysis with the RCB past seasons performance and potential reasons for them not winning a trophy.

# A. Win-Loss Performance Over Seasons

WITH win_loss_record AS (
    SELECT m.Season_Id,CASE WHEN m.Match_Winner = 2 THEN 'Win' ELSE 'Loss' END AS Result
    FROM matches m
    WHERE (m.Team_1 = 2 OR m.Team_2 = 2) AND Outcome_type != 2
)
SELECT Season_Id,COUNT(CASE WHEN Result = 'Win' THEN 1 END) AS Wins,
    COUNT(CASE WHEN Result = 'Loss' THEN 1 END) AS Losses,
    COUNT(*) AS Total_Matches,
    ROUND(COUNT(CASE WHEN Result = 'Win' THEN 1 END) / COUNT(*) * 100, 2) AS Win_Percentage
FROM win_loss_record
GROUP BY Season_Id
ORDER BY Season_Id;

# B. Batting performance each season

WITH rcb_batting_in_death_overs AS (
    SELECT bs.Match_Id, bs.Innings_No, bb.Striker AS Batsman_Id, p.Player_Name,
           SUM(bs.Runs_Scored) AS total_runs_in_power_play,
           COUNT(bb.Ball_Id) AS balls_faced_in_power_play
    FROM Batsman_Scored bs
    JOIN Ball_by_Ball bb ON bs.Match_Id = bb.Match_Id 
                        AND bs.Over_Id = bb.Over_Id
                        AND bs.Ball_Id = bb.Ball_Id
                        AND bs.Innings_No = bb.Innings_No
    JOIN Matches m ON bs.Match_Id = m.Match_Id
    JOIN Player p ON bb.Striker = p.Player_Id 
    WHERE (m.Team_1 = 2 OR m.Team_2 = 2)  
      AND bs.Over_Id BETWEEN 1 AND 6  
    GROUP BY bs.Match_Id, bs.Innings_No, bb.Striker, p.Player_Name
)
SELECT p.Player_Name,
       SUM(rcb.total_runs_in_power_play) AS total_runs_in_power_play,
       SUM(rcb.balls_faced_in_power_play) AS total_balls_faced_in_death_overs,
       ROUND((SUM(rcb.total_runs_in_power_play) / SUM(rcb.balls_faced_in_power_play)) * 100, 2) AS strike_rate_in_power_play
FROM rcb_batting_in_death_overs rcb
JOIN Player p ON rcb.Batsman_Id = p.Player_Id
GROUP BY p.Player_Name
HAVING total_balls_faced_in_death_overs >100
ORDER BY strike_rate_in_power_play DESC;

# C. Bowling performance each season

WITH death_overs_bowling AS (
    SELECT bb.Match_Id, bb.Innings_No, bb.Bowler, p.Player_Name,
           SUM(bs.Runs_Scored) AS runs_conceded,
           COUNT(bb.Ball_Id) AS balls_bowled,
           COUNT(w.Player_Out) AS wickets_taken
    FROM ball_by_ball bb
    JOIN batsman_scored bs ON bb.Match_Id = bs.Match_Id
                          AND bb.Over_Id = bs.Over_Id
                          AND bb.Ball_Id = bs.Ball_Id
                          AND bb.Innings_No = bs.Innings_No
    LEFT JOIN wicket_taken w ON bb.Match_Id = w.Match_Id
                             AND bb.Over_Id = w.Over_Id
                             AND bb.Ball_Id = w.Ball_Id
                             AND bb.Innings_No = w.Innings_No
    JOIN player p ON bb.Bowler = p.Player_Id
    JOIN matches m ON bb.Match_Id = m.Match_Id
    WHERE (m.Team_1 = 2 OR m.Team_2 = 2)  
    AND bb.Over_Id BETWEEN 16 AND 20
    GROUP BY bb.Match_Id, bb.Innings_No, bb.Bowler, p.Player_Name
)
SELECT p.Player_Name,
       SUM(d.runs_conceded) AS runs_conceded_in_death,
       SUM(d.balls_bowled) AS total_balls_bowled_in_death,
       SUM(d.wickets_taken) AS total_wickets_in_death,
       ROUND((SUM(d.runs_conceded) / (SUM(d.balls_bowled) / 6)), 2) AS economy_rate_in_death
FROM death_overs_bowling d
JOIN player p ON d.Bowler = p.Player_Id
JOIN matches m ON d.Match_Id = m.Match_Id
WHERE (m.Team_1 = 2 OR m.Team_2 = 2) 
GROUP BY p.Player_Name
HAVING total_balls_bowled_in_death > 100
ORDER BY economy_rate_in_death DESC;




-- Q11.	In the "Match" table, some entries in the 
-- "Opponent_Team" column are incorrectly spelled as "Delhi_Capitals" instead of "Delhi_Daredevils". 
-- Write an SQL query to replace all occurrences of "Delhi_Capitals" with "Delhi_Daredevils".

UPDATE team
SET Team_Name = "Delhi Daredevils"
WHERE Team_Name = "Delhi Capitals";

 